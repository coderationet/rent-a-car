<?php


require __DIR__ . '/front_routes.php';

require __DIR__.'/auth.php';

require __DIR__ . '/admin_routes.php';

