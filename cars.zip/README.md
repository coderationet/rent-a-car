### Upcoming Features
- [ ] Customizing email content & subject
- [ ] Language customization
- [ ] Currency customization
- [ ] User permissions and roles
- [ ] Blog
- [ ] Newsletter
- [ ] Social media integration
- [ ] Payment gateway integration
- [ ] User profile reservations etc.
