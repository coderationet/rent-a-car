<?php

return [
    'create_new_category' => 'Create New Category',
    'categories' => 'Categories',
    'parent_category' => 'Parent Category',
    'all_categories' => 'All Categories',
    'msg' => [
        'new_category_created_successfully' => 'New Category Created Successfully',
    ]
];
