<?php

return [
    'blog' => 'Blog',
    'blog_content' => 'Blog Content',
    'all_blog_posts' => 'All Blog Posts',
    'new_blog_content' => 'New Blog Content',
    'add_blog' => 'Add Blog',
];
