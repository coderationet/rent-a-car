<?php
return [
    'pages' => 'Pages',
    'all_pages' => 'All Pages',
    'add_page' => 'Add Page',
    'page_content' => 'Page Content',
    'page_type' => 'Page Type',
];
