<?php
return [
    'menu_links' => 'Menu Links',
    'links' => 'Links',
    "add_link" => "Add Link",
    'link_name' => 'Link Name',
    'insert_a_link_name' => 'Insert a link name',
    'insert_a_url' => 'Insert a URL',
    'parent_menu' => 'Parent Menu',
    'all_links' => 'All Links',
];
