<?php
return [
    'items' => 'Items',
    'item' => 'Item',
    'create_new_item' => 'Create New Item',
    'new_item' => 'New Item',
    'item_attributes' => 'Item Attributes',
    'all_items' => 'All Items',
    'add_item' => 'Add Item',
    'msg' => [
        'new_item_created_successfully' => 'New Item Created Successfully',
        'slug_exists' => 'Slug Exists',
        'slug_not_exists' => 'Slug Not Exists',
    ]
];
