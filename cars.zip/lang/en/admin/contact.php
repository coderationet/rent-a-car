<?php

return [
    "contact" => "Contact",
    "contacts" => "Contacts",
    "all_messages" => "All Messages",
    "messages" => "Messages",
    "message_details" => "Message Details",
    "message" => "Message",
];
