<?php

return  [
    'settings' => 'Settings',
    'update_settings' => 'Update Settings',
    'seo_title' => 'SEO Title',
    'seo_description' => 'SEO Description',
    'facebook_url' => 'Facebook URL',
    'twitter_url' => 'Twitter URL',
    'instagram_url' => 'Instagram URL',
    'youtube_url' => 'Youtube URL',
    'footer_html' => 'Footer HTML',
    'header_html' => 'Header HTML',
    "default_payment_gateway" => "Default Payment Gateway",
];
