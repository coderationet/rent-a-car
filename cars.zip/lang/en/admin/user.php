<?php
return [
    'users' => 'Users',
    'user' => 'User',
    'all_users' => 'All Users',
    'new_user' => 'New User',
    'add_user' => 'Add User',
    'permissions' => 'Permissions',
    'roles' => 'Roles',
    'msg' => [
        'change_password_rule' => 'Leave blank if you don\'t want to change the password',
    ]
];
