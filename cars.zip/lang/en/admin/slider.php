<?php
return [
    "slider" => "Slider",
    "sliders" => "Sliders",
    "all_sliders" => "All Sliders",
    "add_new_slider" => "Add New Slider",
    "slider_items" => "Slider Items",
    "add_new_slide_item" => "Add New Slide Item",
    "add_new_slider_item" => "Add New Slider Item",
    "msg" => [
        "slider_created_successfully" => "Slider created successfully",
        "slider_updated_successfully" => "Slider updated successfully",
        "slider_deleted_successfully" => "Slider deleted successfully",
    ]
];
