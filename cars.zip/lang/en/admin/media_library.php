<?php

return [
    "media_library" => "Media Library",
    "choose_file" => "Choose File",
    "choose_image" => "Choose Image",
];
