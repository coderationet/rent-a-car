<?php
return [
    'results' => 'Results',
    'search' => 'Search',
    'price_range' => 'Price Range',
    'results_found' => 'Resuts Found',
    'filter' => 'Filter',
];
