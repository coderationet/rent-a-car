<?php
return [
    'add_new_property' => 'Add New Property',
    'contact' => 'Contact',
    'corporate' => 'Corporate',
    'my_reservation' => 'My Reservations',
    'all_vehicles' => 'All Vehicles',
    'about_us' => 'About Us',
    'account' => 'Account',
    'login' => 'Login',
    'register' => 'Register',
    'logout' => 'Logout',
    'admin' => 'Admin',
    'admin_panel' => 'Admin Panel',
];
