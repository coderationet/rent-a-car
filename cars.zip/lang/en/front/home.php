<?php

return [
    'home' => 'Home',
    'category' => 'Category',
    'categories' => 'Categories',
    'start' => 'Start',
    'end' => 'End',
    'search' => 'Search',
    'search_description' => 'Search vehicles.',
    'all' => 'All',
    'vehicle_categories' => 'Vehicle Categories',
    'vehicle_rental_service' => 'Vehicle Rental Service',
];
