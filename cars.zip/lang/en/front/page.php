<?php
return [
    'pages' => 'Pages',
    'page' => 'Page',
];
