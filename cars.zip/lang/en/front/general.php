<?php
return [
    'home' => 'Home',
    'name' => 'Name',
    'email' => 'Email',
    'phone' => 'Phone',
    'message' => 'Message',
    'submit' => 'Submit',
    'send' => 'Send',
    'details' => 'Details',
    'price' => 'Price',
    'currency_symbol' => '€',
    'currency' => 'EUR',
    'show_more' => 'Show more',
    'show_less' => 'Show less',
];
