<?php

return [
    'msg' => [
        'message_send_successfully' => 'Message send successfully',
    ]
];
