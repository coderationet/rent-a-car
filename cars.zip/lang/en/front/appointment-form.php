<?php
return [
    'title' => 'Appointment Form',
    'book_now' => 'Book Now',
];
