<?php
return [
    'item_calendar' => [
        'availability_calendar_retrieved' => 'Availability calendar retrieved successfully',
    ],
];
