<?php

return [
    'title' => "Car Informations",
    'name' => 'Name',
    'values' => 'Values',
];
