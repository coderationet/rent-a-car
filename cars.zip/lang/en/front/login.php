<?php

return [
    'login' => 'Login',
    'password' => 'Password',
    'email' => 'Email',
    'remember_me' => 'Remember me',
    'forgot_password' => 'Forgot your password?',
];
