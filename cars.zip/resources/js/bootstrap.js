import $ from 'jquery';
import 'jquery-date-range-picker/dist/jquery.daterangepicker.min.js';
import 'jquery-validation/dist/jquery.validate.min.js';
// import inputmask from 'inputmask/bundle.js';
// $.fn.mask = inputmask;
window.$ = window.jQuery = $;
window.jQuery = $;




// import DataTable from 'datatables.net-dt';
// import 'datatables.net-dt/css/jquery.dataTables.css';
// import select2 from 'select2';
// import summerNote from 'summernote/dist/summernote-lite.min.js';
// import 'summernote/dist/summernote-lite.min.css';


// select2($);
