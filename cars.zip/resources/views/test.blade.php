@extends('front.layouts.app')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div id="data-range-conteiner">
                    <input  id="date-range" name="daterange">
                </div>
            </div>
        </div>
    </div>
@endsection
