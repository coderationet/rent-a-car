@extends('mail.layout')
@section('content')

@endsection
