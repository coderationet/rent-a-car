<div {{ $attributes->merge(['class' => 'container mx-auto ']) }}>
    {{ $slot }}
</div>
