<div class="">
    <div class="w-full md:w-1/4 mx-auto my-10 bg-white p-7 rounded shadow">
        {{ $slot }}
    </div>
</div>
