<div>
    <form enctype="multipart/form-data" method="get" id="filter-form" action="<?php echo e(route('front.search.index')); ?>">
        <div class="accordion">
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button" type="button">
                        <?php echo e(__('front/category.results')); ?>

                    </button>
                </h2>
                <div class="accordion-collapse show">
                    <div class="accordion-body">
                        <?php echo e($items->total()); ?> <?php echo e(__('front/category.results_found')); ?>

                    </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button" type="button">
                        <?php echo e(__('admin/category.categories')); ?>

                    </button>
                </h2>
                <div class="accordion-collapse show">
                    <div class="accordion-body">
                        <?php echo \App\Helpers\HierarchicalListingHelper::get_listing_html($categories,$selected_categories,'category[]','slug'); ?>

                    </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button" type="button">
                        <?php echo e(__('front/category.price_range')); ?>

                    </button>
                </h2>
                <div class="accordion-collapse show">
                    <div class="accordion-body price-range">
                        <div class="show-price-range">
                            <input class="form-control" type="text" id="min_price" name="min_price"
                                   value="<?php echo e(request()->has('min_price') ? request()->get('min_price') : $min_price); ?>"
                                   readonly>
                            <input class="form-control" type="text" id="max_price" name="max_price"
                                   value="<?php echo e(request()->has('max_price') ? request()->get('max_price') : $max_price); ?>"
                                   readonly>
                        </div>
                        <div id="price-range" class="slider"></div>
                    </div>
                </div>
            </div>
            <?php $__currentLoopData = $attribute_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button"   type="button">
                            <?php echo e($attribute->name); ?>

                        </button>
                    </h2>
                    <div class="accordion-collapse <?php echo e($attribute->is_open ? 'show' : ''); ?>">
                        <div class="accordion-body">
                            <ul class="list-group">
                                <?php $__currentLoopData = $attribute->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item">
                                        <input type="checkbox" name="attribute_<?php echo e($attribute->slug); ?>[]"
                                               <?php if(request()->has('attribute_'.$attribute->slug) && in_array($attribute_value->id,request('attribute_'.$attribute->slug))): ?>
                                                   checked
                                               <?php endif; ?>
                                               value="<?php echo e($attribute_value->id); ?>"> <?php echo e($attribute_value->value); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <button type="submit" class="bg-blue-500 p-2 text-white w-full hover:bg-blue-600"
                    id="filter-form-submit"><?php echo e(__('front/category.filter')); ?></button>
        </div>
    </form>
</div>
<?php /**PATH C:\laragon\www\cars\resources\views/components/filters.blade.php ENDPATH**/ ?>