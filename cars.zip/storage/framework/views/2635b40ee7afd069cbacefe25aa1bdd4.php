<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <div class="card">
            <div class="card-body">
                <!-- Reservation details -->
                <table>
                    <tr>
                        <td>
                            <h3 class="text-xl">Reservation Details</h3>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <table>
                                <tr>
                                    <td>Reservation number:</td>
                                    <td><?php echo e($reservation->code); ?></td>
                                </tr>
                                <tr>
                                    <td>Reservation date:</td>
                                    <td><?php echo e($reservation->created_at->format('d/m/Y')); ?></td>
                                </tr>
                                <tr>
                                    <td>Reservation status:</td>
                                    <td><?php echo e(strtoupper($reservation->status)); ?></td>
                                </tr>
                                <tr>
                                    <td>Reservation total:</td>
                                    <td><?php echo e(number_format($reservation->payment_amount,2,'.',' ')); ?> €</td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
                <?php echo $bank_transfer_page->content; ?>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cars\resources\views/front/payment/bank_transfer_instructions.blade.php ENDPATH**/ ?>