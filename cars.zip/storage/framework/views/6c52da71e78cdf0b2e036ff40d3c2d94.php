<?php
    $multiple_file = isset($multiple_file) && $multiple_file ;
?>
<?php if($multiple_file): ?>
    <?php
        $input_value = isset($item) && $item->$relation->count() ? implode(',',$item->$relation->pluck('id')->toArray()) : '';
    ?>
    <input type="hidden" name="<?php echo e($input_name); ?>"
           id="<?php echo e($input_name); ?>"
           class="gc-image-library-field"
           <?php echo e(isset($multiple_file) && $multiple_file ? 'multiple' : ''); ?>

           value="<?php echo e($input_value); ?>">
    <?php if(isset($item) && $item->$relation->count()): ?>
        <div class="gc-library-preview-container multiple-image has-image"
             data-element-id="file_desktop">
            <?php $__currentLoopData = $item->$relation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="image-item">
                    <?php if($media_item->type == 'image'): ?>
                        <img src="<?php echo e(asset('storage/media/'.$media_item->name)); ?>"
                             alt="<?php echo e($media_item->name); ?>">
                    <?php endif; ?>
                    <?php if($media_item->type == 'video'): ?>
                        <video style="width: 100%" controls>
                            <source
                                src="<?php echo e(asset('storage/media/'.$media_item->name)); ?>"
                                type="video/mp4">
                            Your browser does not support the video tag.
                        </video>
                    <?php endif; ?>
                    <?php if($media_item->type == 'application'): ?>
                        <div>
                            <img src="<?php echo e(asset('storage/media/default/file.jpg')); ?>">
                            <a href="<?php echo e(asset('storage/media/'.$media_item->name)); ?>"
                               target="_blank" class="btn btn-primary btn-sm">İndir</a>
                        </div>
                    <?php endif; ?>
                    <div class="remove-item" data-element-id="<?php echo e($input_name); ?>" data-file-id="<?php echo e($media_item->id); ?>">Sil
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="gc-image-preview-container-buttons">
            <?php if(\App\Helpers\PermissionHelper::checkIfUserHasPermission(\App\Enums\PermissionEnum::MEDIA_READ)): ?>
                <button type="button" class="btn btn-primary btn-sm multiple-image add-new"
                        data-element-id="<?php echo e($input_name); ?>"> Yeni Ekle
                </button>
            <?php endif; ?>
        </div>
    <?php endif; ?>
<?php else: ?>
    <input type="hidden" name="<?php echo e($input_name); ?>"
           class="gc-image-library-field"
           id="<?php echo e($input_name); ?>"
           value="<?php echo e(isset($item) ? $item->$input_name : ''); ?>">

    <?php if(isset($item) && !empty($item->$relation )): ?>
        <div class="gc-library-preview-container single-image"
             data-element-id="file_desktop">
            <?php if($item->$relation->type == 'image'): ?>
                <img src="<?php echo e(asset('storage/media/'.$item->$relation->name)); ?>"
                     alt="<?php echo e($item->$relation->name); ?>" CLASS="cursor-pointer">
            <?php endif; ?>
            <?php if($item->$relation->type == 'video'): ?>
                <video style="width: 100%" controls>
                    <source
                        src="<?php echo e(asset('storage/media/'.$item->$relation->name)); ?>"
                        type="video/mp4">
                    Your browser does not support the video tag.
                </video>
            <?php endif; ?>
        </div>
        <div class="gc-image-preview-container-buttons">
            <?php if(\App\Helpers\PermissionHelper::checkIfUserHasPermission(\App\Enums\PermissionEnum::MEDIA_READ)): ?>
                <button type="button" class="btn btn-primary btn-sm add-new single-image"
                        data-element-id="<?php echo e($input_name); ?>">
                    Yeni Ekle
                </button>
            <?php endif; ?>
            <button type="button" class="btn btn-primary btn-sm remove single-image" data-element-id="<?php echo e($input_name); ?>">
                Kaldır
            </button>
        </div>
    <?php endif; ?>
<?php endif; ?>
<?php if (! $__env->hasRenderedOnce('8691b4d3-caa5-420a-8d91-cebad45b67b6')): $__env->markAsRenderedOnce('8691b4d3-caa5-420a-8d91-cebad45b67b6');
$__env->startPush('extra-footer'); ?>
    <?php echo $__env->make('admin.media_library.form-dialog-includes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); endif; ?>
<?php /**PATH C:\laragon\www\cars\resources\views/admin/media_library/_input.blade.php ENDPATH**/ ?>