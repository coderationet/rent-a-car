<div class="flex flex-col gap-5">
    <h2 class="text-xl font-bold">
        <?php echo e($item->title); ?>

    </h2>
    <img src="<?php echo e(route('front.image.show.mode',['image_id' => $item->thumbnail_id,'size' => 'medium','mode' => 'fill'])); ?>" alt="<?php echo e($item->title); ?>" class="w-full">
    <div class="flex">
        <span>Pick Up Date:</span>
        <span class="ml-auto"><?php echo e($start_date); ?></span>
    </div>
    <div class="flex">
        <span>Drop Off Date:</span>
        <span class="ml-auto"><?php echo e($end_date); ?></span>
    </div>
    <div class="flex">
        <small>
            <a class="font-bold" href="<?php echo e(route('front.page.show',\App\Models\Page::find(2)->slug)); ?>">Click</a> to see rental terms and conditions.
        </small>
    </div>
</div>
<?php /**PATH C:\laragon\www\cars\resources\views/front/appointment/partials/summary.blade.php ENDPATH**/ ?>