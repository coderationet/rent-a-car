<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e(__('admin/general.dashboard')); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#"><?php echo e(__('admin/general.home')); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e(__('admin/item.items')); ?></li>
                            <li class="breadcrumb-item active"><?php echo e(__('admin/item.new_item')); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <section class="content">
            <div class="container-fluid">
                <form action="<?php echo e(isset($item) ? route('admin.items.update',$item->id)  : route('admin.items.store')); ?>"
                      method="post">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($item)): ?>
                        <?php echo method_field('PUT'); ?>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-md-9">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card card-primary">

                                        <div class="card-header">
                                            <h3 class="card-title"><?php echo e(__('admin/general.add_new')); ?></h3>
                                        </div>

                                        <div class="card-body item-form">
                                            <div class="form-group">
                                                <label for="title"><?php echo e(__('admin/general.title')); ?></label>
                                                <input type="text" class="form-control" id="title"
                                                       value="<?php echo e(isset($item) ? $item->title : ''); ?>"
                                                       name="title"
                                                       required
                                                       placeholder="<?php echo e(__('admin/general.title')); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="slug"><?php echo e(__('admin/general.slug')); ?></label>
                                                <input type="text" class="form-control" id="slug"
                                                       value="<?php echo e(isset($item) ? $item->slug : ''); ?>"
                                                       name="slug"
                                                       required
                                                       placeholder="<?php echo e(__('admin/general.slug')); ?>">
                                                <div class="alert alert-success d-none mt-2"></div>
                                                <div class="alert alert-danger d-none mt-2"></div>
                                            </div>
                                            <!-- Price -->
                                            <div class="form-group">
                                                <label for="price"><?php echo e(__('admin/general.price')); ?></label>
                                                <input type="number" class="form-control" id="price"
                                                       value="<?php echo e(isset($item) ? $item->price : ''); ?>"
                                                       name="price"
                                                       required
                                                       placeholder="<?php echo e(__('admin/general.price')); ?>">
                                            </div>
                                            <!-- description part -->
                                            <div class="form-group">
                                                <label for="description"><?php echo e(__('admin/general.description')); ?></label>
                                                <textarea class="form-control custom-editor" id="description" rows="3"
                                                          name="description"
                                                          required
                                                          placeholder="Açıklama Giriniz"><?php echo e(isset($item) ? $item->description : ''); ?></textarea>
                                            </div>
                                        </div>

                                        <div class="card-footer">
                                            <?php if(\App\Helpers\PermissionHelper::checkIfUserHasPermission(\App\Enums\PermissionEnum::ITEMS_UPDATE)): ?>
                                                <button type="submit" class="btn btn-primary">
                                                    <?php echo e(isset($item) ? __('admin/general.update') : __('admin/general.add_new')); ?>

                                                </button>
                                            <?php endif; ?>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <?php echo $__env->make('admin.items._attribute_values',[
                                        "item_attributes" => $item_attributes,
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title">
                                                <?php echo e(__('admin/general.featured_image')); ?>

                                            </h3>
                                        </div>
                                        <div class="card-body">
                                            <?php echo $__env->make('admin.media_library._input',[
                                                    "input_name"=>"thumbnail_id",
                                                    "relation" => "thumbnail",
                                                    "item" => isset($item) ? $item : null,
                                                    "multiple_file" => false
                                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title">
                                                <?php echo e(__('admin/general.gallery')); ?>

                                            </h3>
                                        </div>
                                        <div class="card-body">
                                            <?php echo $__env->make('admin.media_library._input',[
                                                    "input_name"=>"gallery_ids",
                                                    "relation" => "gallery",
                                                    "multiple_file" => true,
                                                    "item" => isset($item) ? $item : null
                                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title">
                                                <?php echo e(__('admin/category.categories')); ?>

                                            </h3>
                                        </div>
                                        <div class="card-body category-listing-block">
                                            <?php echo \App\Helpers\HierarchicalListingHelper::get_listing_html($categories,$selected_categories,'categories[]'); ?>

                                        </div>
                                        <div class="card-footer">
                                            <button type="button" class="btn btn-primary" data-toggle="modal"
                                                    id="create-new-category-button"
                                                    data-target="#create-new-category-modal">
                                                <?php echo e(__('admin/category.create_new_category')); ?>

                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('extra-footer'); ?>

    <!-- Modal to create new category dialog -->
    <!-- Modal -->
    <div class="modal fade" id="create-new-category-modal" tabindex="-1" role="dialog"
         aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('admin/category.create_new_category')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button"
                            class="btn btn-primary create-new-category-ajax"><?php echo e(__('admin/general.add_new')); ?></button>
                </div>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/admin/summernote/custom-image-dialog.plugin.js')); ?>"></script>
    <?php echo $__env->make('admin.js.summernote-turkish', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script type="module">

        $('.item-form #title').change(function () {
            if ($('.item-form #slug').val() == '') {
                $.get('<?php echo e(route('admin.generate-slug')); ?>', {title: $(this).val()}, function (data) {
                    $('.item-form #slug').val(data.slug);
                });
            }
        });

        $('#slug').change(function (e) {
            // doesnt allow space and special chars except -
            $.get('<?php echo e(route('admin.generate-slug')); ?>', {title: $(this).val()}, function (data) {
                $('.item-form #slug').val(data.slug);
            });
        });

        $('.item-form #slug').keyup(function (e) {


            var except_post_id = '';

            <?php if(isset($item)): ?>
                except_post_id = '<?php echo e($item->id); ?>';
            <?php endif; ?>

            $.get("<?php echo e(route('admin.items.get_item')); ?>?slug=" + $(this).val() + "&except_post_id=" + except_post_id, function (data) {

                if (data.exists === true) {

                    $('.item-form .alert-success').addClass('d-none');
                    $('.item-form .alert-danger').removeClass('d-none');
                    $('.item-form .alert-danger').html(data.msg);

                } else {

                    $('.item-form .alert-success').removeClass('d-none');
                    $('.item-form .alert-danger').addClass('d-none');
                    $('.item-form .alert-success').html(data.msg);

                }
            });
        });

        $(document).on('click', '.create-new-category-ajax', function () {
            var form_data = '';
            // add csrf token to form data get token from meta
            form_data = form_data + '&_token=' + $('meta[name="csrf-token"]').attr('content');
            // add name to form data
            form_data = form_data + '&name=' + $('#create-new-category-modal #category').val();
            // add parent_id to form data
            form_data = form_data + '&parent_id=' + $('#create-new-category-modal #parent_id').val() ?? null;
            // add return_type to form data
            form_data = form_data + '&response_type=json';
            // send selected categories
            var selected_categories = [];
            // get checked values from category-listing-block input checkbox
            $('.category-listing-block input[type=checkbox]:checked').each(function () {
                selected_categories.push($(this).val());
            });
            // add selected categories to form data
            form_data = form_data + '&selected_categories=' + selected_categories;
            $.ajax({
                method: 'POST',
                url: '<?php echo e(route('admin.item-categories.store')); ?>',
                data: form_data,
                success: function (response) {
                    if (response.status == 'success') {
                        $(document).Toasts('create', {
                            class: 'bg-success',
                            title: '<?php echo e(__('admin/general.success')); ?>',
                            subtitle: '',
                            body: response.msg
                        });
                        $('#create-new-category-modal').modal('hide');
                        $('.category-listing-block').html(response.category_block_html);
                    } else {
                        $(document).Toasts('create', {
                            class: 'bg-danger',
                            title: '<?php echo e(__('admin/general.error')); ?>',
                            subtitle: '',
                            body: response.msg
                        });
                    }
                }
            });
        });
        $(function () {

            $(document).on('click', '#create-new-category-button', function () {

                var modal_body_html = $.ajax({
                    method: 'GET',
                    url: '<?php echo e(route('admin.item-categories.new_category_form_html')); ?>',
                    async: false
                }).responseText;

                $('#create-new-category-modal .modal-body').html(modal_body_html);

            });

            $(document).on('click', '')

            // Summernote
            $('#description').summernote({
                // lang: 'tr-TR',
                tabsize: 2,
                minHeight: 300,
                toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'underline', 'clear']],
                    ['fontname', ['fontname']],
                    ['fontsize', ['fontsize']],
                    ['color', ['color']],
                    ['para', ['ul', 'ol', 'paragraph']],
                    ['insert', ['examplePlugin', 'link']],
                    ['style', ['bold', 'italic', 'underline', 'clear']],
                    ['font', ['strikethrough', 'superscript', 'subscript']],
                    ['view', ['codeview']],
                ]
            });
        });
    </script>
    <style>
        .category-listing-block {
            max-height: 400px;
            overflow-y: scroll;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cars\resources\views/admin/items/edit.blade.php ENDPATH**/ ?>