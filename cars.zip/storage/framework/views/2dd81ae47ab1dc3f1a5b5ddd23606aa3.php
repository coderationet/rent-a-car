<?php $__env->startSection('title', $page->name); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('front.breadcrumbs',['breadcrumbs' => [
        ['name' => 'Home', 'url' => route('front.home')],
        ['name' => __('front/menu.contact'), 'url' => route('front.page.contact')]
    ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container page">
        <div class="flex flex-row gap-3">
            <div class="w-1/4 bg-white p-3 h-max">
                <?php if (isset($component)) { $__componentOriginalb3178872fdf630b269268f563f3c79c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3178872fdf630b269268f563f3c79c4 = $attributes; } ?>
<?php $component = App\View\Components\PageSidebar::resolve(['page' => $page] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('page-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\PageSidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3178872fdf630b269268f563f3c79c4)): ?>
<?php $attributes = $__attributesOriginalb3178872fdf630b269268f563f3c79c4; ?>
<?php unset($__attributesOriginalb3178872fdf630b269268f563f3c79c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3178872fdf630b269268f563f3c79c4)): ?>
<?php $component = $__componentOriginalb3178872fdf630b269268f563f3c79c4; ?>
<?php unset($__componentOriginalb3178872fdf630b269268f563f3c79c4); ?>
<?php endif; ?>
            </div>
            <div class="w-3/4 bg-white p-3">
                <h1 class="text-2xl mb-4"><?php echo e($page->name); ?></h1>
                <div class="mb-3">
                    <?php if(session()->has('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session()->get('error')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('success')); ?>

                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('front.page.contact.post')); ?>" method="post" enctype="multipart/form-data" class="flex gap-5 flex-col">
                        <?php echo csrf_field(); ?>
                        <!-- name -->
                        <div class="flex flex-col gap-3">
                            <label for="name"><?php echo e(__('front/general.name')); ?></label>
                            <input type="text" name="name" required id="name" class="form-control"
                                   value="<?php echo e(old('name')); ?>">
                        </div>
                        <!-- message select -->
                        <div class="flex flex-col gap-3 ">
                            <label for="message"><?php echo e(__('front/general.message')); ?></label>
                            <textarea name="message" required id="message" class="form-control"
                                      style="min-height: 200px"><?php echo e(old('message')); ?></textarea>
                        </div>
                        <!-- submit -->
                        <div class="form-group mt-3">
                            <button type="submit"
                                    class="primary-bg hover:bg-blue-500 p-3 px-5 text-white rounded"><?php echo e(__('front/general.send')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cars\resources\views/front/page/contact.blade.php ENDPATH**/ ?>