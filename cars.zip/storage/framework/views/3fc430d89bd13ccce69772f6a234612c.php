<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">

        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e(__('admin/general.dashboard')); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#"><?php echo e(__('admin/general.home')); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e(__('admin/role.roles')); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <section class="content">
            <div class="container-fluid">
                <!-- Main row -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title pt-2"><?php echo e(__('admin/item.items')); ?></h3>
                                <a href="<?php echo e(route('admin.items.create')); ?>" class="btn btn-primary float-right"><?php echo e(__('admin/general.create_new')); ?></a>
                            </div>
                            <div class="card-body">
                                <table id="items" class="table table-bordered table-hover">
                                    <thead>
                                    <tr>
                                        <th>#ID</th>
                                        <th><?php echo e(__('admin/general.title')); ?></th>
                                        <th><?php echo e(__('admin/general.description')); ?></th>
                                        <th><?php echo e(__('admin/general.actions')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <tfoot>
                                    <tr>
                                        <th>#ID</th>
                                        <th><?php echo e(__('admin/general.title')); ?></th>
                                        <th><?php echo e(__('admin/general.description')); ?></th>
                                        <th><?php echo e(__('admin/general.actions')); ?></th>
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin')); ?>/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet"
          href="<?php echo e(asset('assets/admin')); ?>/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin')); ?>/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">

<?php $__env->stopSection(); ?>

<?php $__env->startPush('extra-footer'); ?>
    <?php echo $__env->make('admin.layouts.datatable-lang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.layouts.datatable-files', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.layouts.datatable-config.product-items', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cars\resources\views/admin/authorizon/role/index.blade.php ENDPATH**/ ?>