<?php if(count($filters['filter_values']) || count($filters['categories'])): ?>
    <div class="bg-white rounded p-3 border mb-3 active-filters">
        <div class="item bg-white">
            <div class="row">
                <div
                    data-show-more-text="<?php echo e(__('front/general.show_more')); ?>"
                    class="flex flex-wrap gap-3 filter-items">
                    <?php $__currentLoopData = $filters['filter_values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex rounded border filter-item ">
                            <button type="button"
                                    class="p-2"><?php echo e($filter['value']); ?></button>
                            <button type="button" class="border-l p-2 hover:bg-gray-300 remove-filter"
                                    data-url="<?php echo e(route('front.search.remove_filter_from_url')); ?>"
                                    data-attribute-value-id="<?php echo e($filter['id']); ?>">
                                <?php echo $__env->make('icons.trash', ['class' => 'w-4 h-4'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </button>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $filters['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="flex rounded border filter-item ">
                            <button type="button"
                                    class="p-2"><?php echo e($category['name']); ?></button>
                            <button type="button" class="border-l p-2 hover:bg-gray-300 remove-filter"
                                    data-url="<?php echo e(route('front.search.remove_filter_from_url')); ?>"
                                    data-attribute-value-id="<?php echo e($category['id']); ?>">
                                <?php echo $__env->make('icons.trash', ['class' => 'w-4 h-4'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </button>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\cars\resources\views/components/active-filters.blade.php ENDPATH**/ ?>