<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('front.breadcrumbs', ['breadcrumbs' => [
        [
            'name' => __('front/general.home'),
            'url' => route('front.home')
        ],
        [
            'name' => __('admin/general.search'),
            'url' => route('front.search.index')
        ]
    ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container category-page page">
        <div class="flex gap-5">
            <div class="w-1/4 mb-3 filters-sidebar hidden md:block">
                <?php if (isset($component)) { $__componentOriginal60fb4288a27195311c97ea53464d429b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60fb4288a27195311c97ea53464d429b = $attributes; } ?>
<?php $component = App\View\Components\Filters::resolve(['items' => $items,'categoryids' => isset($category) ? $category : null] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filters'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Filters::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60fb4288a27195311c97ea53464d429b)): ?>
<?php $attributes = $__attributesOriginal60fb4288a27195311c97ea53464d429b; ?>
<?php unset($__attributesOriginal60fb4288a27195311c97ea53464d429b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60fb4288a27195311c97ea53464d429b)): ?>
<?php $component = $__componentOriginal60fb4288a27195311c97ea53464d429b; ?>
<?php unset($__componentOriginal60fb4288a27195311c97ea53464d429b); ?>
<?php endif; ?>
            </div>
            <div class="w-full md:w-3/4">
                <?php if (isset($component)) { $__componentOriginal2778220205ca08aa0498b6eb70e09e5c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2778220205ca08aa0498b6eb70e09e5c = $attributes; } ?>
<?php $component = App\View\Components\ActiveFilters::resolve(['category' => $category] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('active-filters'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ActiveFilters::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2778220205ca08aa0498b6eb70e09e5c)): ?>
<?php $attributes = $__attributesOriginal2778220205ca08aa0498b6eb70e09e5c; ?>
<?php unset($__attributesOriginal2778220205ca08aa0498b6eb70e09e5c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2778220205ca08aa0498b6eb70e09e5c)): ?>
<?php $component = $__componentOriginal2778220205ca08aa0498b6eb70e09e5c; ?>
<?php unset($__componentOriginal2778220205ca08aa0498b6eb70e09e5c); ?>
<?php endif; ?>
                <div class="flex flex-col">
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="rounded bg-white p-3 border mb-5">
                            <div class="flex gap-3">
                                <div class="w-1/3">
                                    <a href="<?php echo e(route('front.item.show',$item->slug) . $date_string); ?>">
                                        <img
                                            src="<?php echo e(route('front.image.show.mode',['image_id' => $item->thumbnail->id,'size' => 'small','mode' => 'stretch'])); ?>"
                                            alt=""
                                            loading="lazy"
                                            class="w-full">
                                    </a>
                                </div>
                                <div class="w-2/3">
                                    <div class="111">
                                        <div>
                                            <a href="<?php echo e(route('front.item.show',$item->slug)); ?>"
                                               class="text-decoration-none text-black">
                                                <h2 class="text-xl"><?php echo e($item->title); ?></h2>
                                            </a>
                                            <p class="text-gray fs-12"><?php echo e($item->attributeValues[0]->value); ?></p>
                                            <div class="d-flex gap-1">
                                                <?php $__currentLoopData = $item->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="badge bg-primary"><?php echo e($category->name); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <p class="peoppe">
                                                <i class="fas fa-user"></i> <?php echo e($item->attributeValues[1]->value); ?>

                                            </p>
                                            <p class="price">
                                                <?php echo e(number_format($item->price,2,',','.')); ?> ₺
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($items->hasPages()): ?>
                        <div class="">
                            <?php echo e($items->links()); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app',[
    'title' => isset($title) ? $title : null,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cars\resources\views/front/search/show.blade.php ENDPATH**/ ?>