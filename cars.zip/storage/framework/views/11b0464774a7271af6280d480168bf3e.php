<!-- edit update delete action buttons for $item -->
<a href="<?php echo e(route('admin.reservations.edit', $reservation->id)); ?>" class="btn btn-primary btn-xs">
    <i class="fa fa-edit"></i>
    <?php echo e(__('admin/general.edit')); ?></a>
<form action="<?php echo e(route('admin.reservations.destroy', $reservation->id)); ?>" method="POST" style="display: inline-block;">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button
        onclick="return confirm('<?php echo e(__('admin/general.are_you_sure_to_delete')); ?>');"
        type="submit" class="btn btn-danger btn-xs">
        <i class="fa fa-trash"></i>
        <?php echo e(__('admin/general.delete')); ?></button>
</form>
<?php /**PATH C:\laragon\www\cars\resources\views/admin/reservations/actions.blade.php ENDPATH**/ ?>