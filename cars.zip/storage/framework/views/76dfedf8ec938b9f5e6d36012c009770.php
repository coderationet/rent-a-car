<td>
    <?php if(isset($editUrl)): ?>
        <a href="<?php echo e($editUrl); ?>" class="btn btn-xs btn-primary">
            <i class="fa fa-edit"></i>
            Edit
        </a>
    <?php endif; ?>
    <?php if(isset($deleteUrl)): ?>
        <form action="<?php echo e($deleteUrl); ?>" method="POST" style="display: inline-block;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-xs btn-danger" onclick="return confirm('Are you sure you want to delete this item?')">
                <i class="fa fa-trash"></i>
                Delete
            </button>
        </form>
    <?php endif; ?>

</td>
<?php /**PATH C:\laragon\www\cars\resources\views/admin/layouts/datatable-actions.blade.php ENDPATH**/ ?>