<script>
    var datatable_tr = {
        "sEmptyTable": "<?php echo e(__('admin/datatable.sEmptyTable')); ?>",
        "sInfo": "<?php echo e(__('admin/datatable.sInfo')); ?>",
        "sInfoEmpty": "<?php echo e(__('admin/datatable.sInfoEmpty')); ?>",
        "sInfoFiltered": "<?php echo e(__('admin/datatable.sInfoFiltered')); ?>",
        "sInfoPostFix": "<?php echo e(__('admin/datatable.sInfoPostFix')); ?>",
        "sInfoThousands": "<?php echo e(__('admin/datatable.sInfoThousands')); ?>",
        "sLengthMenu": "<?php echo e(__('admin/datatable.sLengthMenu')); ?>",
        "sLoadingRecords": "<?php echo e(__('admin/datatable.sLoadingRecords')); ?>",
        "sProcessing": "<?php echo e(__('admin/datatable.sProcessing')); ?>",
        "sSearch": "<?php echo e(__('admin/datatable.sSearch')); ?>",
        "sZeroRecords": "<?php echo e(__('admin/datatable.sZeroRecords')); ?>",
        "oPaginate": {
            "sFirst": "<?php echo e(__('admin/datatable.oPaginate.sFirst')); ?>",
            "sLast": "<?php echo e(__('admin/datatable.oPaginate.sLast')); ?>",
            "sNext": "<?php echo e(__('admin/datatable.oPaginate.sNext')); ?>",
            "sPrevious": "<?php echo e(__('admin/datatable.oPaginate.sPrevious')); ?>"
        },
        "oAria": {
            "sSortAscending": "<?php echo e(__('admin/datatable.oAria.sSortAscending')); ?>",
            "sSortDescending": "<?php echo e(__('admin/datatable.oAria.sSortDescending')); ?>"
        }
    }
</script>
<?php /**PATH C:\laragon\www\cars\resources\views/admin/layouts/datatable-lang.blade.php ENDPATH**/ ?>