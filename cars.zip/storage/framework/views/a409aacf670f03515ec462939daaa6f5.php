<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">

        <section class="content-header">

            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo e(__('admin/category.categories')); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('admin/general.home')); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e(__('admin/category.categories')); ?></li>
                        </ol>
                    </div>
                </div>
            </div>

        </section>

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"><?php echo e(__('admin/category.all_categories')); ?></h3>
                                <a href="<?php echo e(route('admin.item-categories.create')); ?>"
                                   class="btn btn-primary btn-xs float-right"><i
                                        class="fas fa-plus"></i> <?php echo e(__('admin/general.add_new')); ?></a>
                            </div>

                            <div class="card-body">
                                <table id="item_categories" class="table table-bordered table-hover">
                                    <thead>
                                    <tr>
                                        <th>#ID</th>
                                        <th><?php echo e(__('admin/general.name')); ?></th>
                                        <th><?php echo e(__('admin/general.actions')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>                                  
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <th>>#ID</th>
                                        <th><?php echo e(__('admin/general.name')); ?></th>
                                        <th><?php echo e(__('admin/general.actions')); ?></th>
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </section>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('extra-footer'); ?>

    <?php echo $__env->make('admin.layouts.datatable-lang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.layouts.datatable-files', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script type="module">
        $(function () {
            $('#item_categories').DataTable({
                "language": datatable_tr,
                "paging": true,
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": "<?php echo e(route('admin.data-table.data')); ?>",
                    "type": "GET",
                    "dataSrc": "data",
                    "dataType": "json",
                    "data" : {
                        "table_name" : "item_categories",
                        "route_name_prefix" : "admin.item-categories"
                    }
                },
                "columns": [
                    {"data": "id"},
                    {"data": "name"},
                    {"data": "actions"},
                ],
                "order": [[0, "desc"]],
            });
        });
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin.layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cars\resources\views/admin/item_category/index.blade.php ENDPATH**/ ?>