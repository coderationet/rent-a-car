<?php echo $__env->make('admin.form._input',[
                                        'input_name'=>'name',
                                        'title'=>__('admin/general.name'),
                                        'placeholder'=>__('admin/attributes.insert_attribute_name'),
                                        'item' => $attribute ?? null
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.form._input',[
    'input_name'=>'slug',
    'title'=>__('admin/general.slug'),
    'placeholder'=>__('admin/attributes.insert_attribute_slug'),
    'item' => $attribute ?? null,
    'with_alerts' => true
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="form-group">
    <label for="type"><?php echo e(__('admin/general.type')); ?></label>
    <select id="type" name="type" class="form-control">
        <option
            <?php if(isset($attribute) && $attribute->type == "select"): ?>
                selected
            <?php endif; ?>
            value="select"><?php echo e(__('admin/general.select')); ?></option>
        <option
            <?php if(isset($attribute) && $attribute->type == "multiselect"): ?>
                selected
            <?php endif; ?>
            value="multiselect"><?php echo e(__('admin/general.multiselect')); ?></option>
    </select>
</div>
<?php /**PATH C:\laragon\www\cars\resources\views/admin/item_attribute/_form.blade.php ENDPATH**/ ?>