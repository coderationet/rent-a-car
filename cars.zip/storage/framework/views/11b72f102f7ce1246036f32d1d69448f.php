<div class="container mt-3">
    <nav>
        <ol class="breadcrumb">
            <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($loop->index > 0 && $loop->index < count($breadcrumbs)): ?>
                    <?php echo e(view('icons.chevron-right',['class' => 'w-3 h-3'])); ?>

                <?php endif; ?>
                <li class="breadcrumb-item active"><a href="<?php echo e($breadcrumb['url']); ?>"><?php echo e($breadcrumb['name']); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
    </nav>
</div>
<?php /**PATH C:\laragon\www\cars\resources\views/front/breadcrumbs.blade.php ENDPATH**/ ?>