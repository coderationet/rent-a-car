<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">


            <iframe src="<?php echo e(route('admin.media-library.iframe')); ?>?page=library-index" frameborder="0"
                    style="width: 100%; height: 100vh"></iframe>


    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-css'); ?>
    <style>
        .content-wrapper {
            min-height: 100vh !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cars\resources\views/admin/media_library/index.blade.php ENDPATH**/ ?>