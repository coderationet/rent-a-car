<div class="form-group <?php echo e(isset($classes) ? $classes : ''); ?>">
    <label for="<?php echo e($input_name); ?>"><?php echo e($title); ?></label>
    <input type="text" class="form-control <?php echo e($input_name); ?>" id="<?php echo e($input_name); ?>"
           name="<?php echo e($input_name); ?>"
           <?php if(isset($item)): ?>
               value="<?php echo e($item->$input_name); ?>"
           <?php endif; ?>

           <?php if(isset($required)): ?>
               required
           <?php endif; ?>

           <?php if(isset($placeholder)): ?>
               placeholder="<?php echo e($placeholder); ?>"
           <?php endif; ?>
           <?php if(isset($value)): ?>
               value="<?php echo e($value); ?>"
        <?php endif; ?>
    >

    <?php if(isset($with_alerts) && $with_alerts == true): ?>
        <div class="alert alert-success d-none mt-3"></div>
        <div class="alert alert-danger d-none mt-3"></div>
    <?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\cars\resources\views/admin/form/_input.blade.php ENDPATH**/ ?>