<div>
    <ul>
        <li class="font-bold mb-3">Pages</li>
        <li><a href="<?php echo e(route('front.page.show',['about'])); ?>">About</a></li>
        <li><a href="<?php echo e(url('contact')); ?>">Contact</a></li>
        <li><a href="">Blog</a></li>
    </ul>
</div>
<div>
    <ul>
        <li class="font-bold mb-3">Categories</li>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('front.search.index').'/'.$category->slug); ?>"><?php echo e($category->name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>

<?php /**PATH C:\laragon\www\cars\resources\views/components/footer.blade.php ENDPATH**/ ?>