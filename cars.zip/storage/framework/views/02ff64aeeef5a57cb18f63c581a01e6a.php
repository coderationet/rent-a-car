<?php $__env->startSection('title', $item->title); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('front.breadcrumbs', ['breadcrumbs' => [
        [
            'name' => __('front/general.home'),
            'url' => route('front.home')
        ],
        [
            'name' => $item->title,
            'url' => route('front.item.show', $item->slug)
        ]
    ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container flex flex-col md:flex-row gap-5 item-page">
            <div class="w-full flex-1 flex flex-col gap-4">
                <div class="card">
                    <div class="card-body">
                        <!-- Slider main container -->
                        <div class="swiper item-slider">
                            <!-- Additional required wrapper -->
                            <div class="swiper-wrapper">
                                <?php $__currentLoopData = [$item->thumbnail, ...$item->gallery]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide text-center">
                                        <img src="<?php echo e(route('front.image.show.mode',[$image->id,'big','fill'])); ?>" loading="lazy" alt="<?php echo e($item->title); ?>" class="slider-image">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <!-- If we need pagination -->
                            <div class="swiper-pagination"></div>

                            <!-- If we need navigation buttons -->
                            <div class="swiper-button-prev"></div>
                            <div class="swiper-button-next"></div>

                            <!-- If we need scrollbar -->
                            <div class="swiper-scrollbar"></div>
                        </div>
                    </div>
                    <div class="card-footer fs-5 p-3 ">

                        <div class="flex flex-col justify-end items-start">
                            <h2 class="text-2xl mb-3"><?php echo e($item->title); ?></h2>
                            <?php echo $item->description; ?>

                        </div>

                    </div>
                </div>
                <div class="card p-3">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <?php echo e(__('front/item-informations.title')); ?>

                        </h5>
                    </div>
                    <div class="card-body">
                        <table class="table-bordered w-full">
                            <thead>
                            <tr>
                                <th class="col-md-3 p-2"><?php echo e(__('front/item-informations.name')); ?></th>
                                <th class="col-md-9 p-2"><?php echo e(__('front/item-informations.values')); ?></th>
                            </tr>
                            <tbody>
                            <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="col-md-3 p-2"><?php echo e($attribute['name']); ?></td>
                                    <td class="col-md-9 p-2"><?php echo e(implode(',',collect($attribute['values'])->pluck('name')->toArray())); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="w-full appointment-form-sidebar flex flex-col">
                <div class="sticky">
                    <?php echo $__env->make('front.item.contact-informations', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('front.item.appointment-form',['item' => $item,'date_value' => $date_value,'available_dates' => $available_dates], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cars\resources\views/front/item/show.blade.php ENDPATH**/ ?>