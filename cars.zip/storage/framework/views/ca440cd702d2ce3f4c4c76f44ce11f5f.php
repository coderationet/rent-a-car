<div class="mb-3 h-max">
    <ul class="flex flex-col ">
        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page_): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li
                class="
                 p-3
                <?php if($page_->id == $page->id): ?>
                    text-white bg-gray-400
            <?php else: ?>
            hover:bg-gray-400
            hover:text-white
            <?php endif; ?>">
                <a href="<?php echo e(route('front.page.show', $page_->slug)); ?>"><?php echo e($page_->name); ?></a>
            </li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- Contact page -->
        <li
            class="
                 p-3
                <?php if(request()->routeIs('front.page.contact')): ?>
            text-white bg-gray-400
            <?php else: ?>
            hover:bg-gray-400
            hover:text-white
            <?php endif; ?>"
        >
            <a href="<?php echo e(route('front.page.contact')); ?>"
            ><?php echo e(__('front/menu.contact')); ?></a>
        </li>
    </ul>
</div>
<?php /**PATH C:\laragon\www\cars\resources\views/components/page-sidebar.blade.php ENDPATH**/ ?>