<?php $__env->startSection('content'); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Profile')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="p-6 md:py-12 md:p-0 ">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <div class="flex gap-5 flex-col md:flex-row">
                <div class="w-full md:w-1/4">
                    <div class="bg-white shadow ">
                        <div class="max-w-xl">
                            <?php echo $__env->make('profile.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
                <div class="w-full md:w-3/4">
                    <div class="bg-white shadow rounded">
                        <div class="max-w-xl">
                            <div class="p-6">
                                <h2 class="text-2xl font-semibold text-gray-800">Reservations</h2>
                            </div>
                        </div>
                    </div>
                    <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white shadow rounded p-6 mt-4">
                            <div class="flex flex-col gap-3">
                                <a href="<?php echo e(route('front.item.show',$reservation->item->slug)); ?>" target="_blank">
                                    <h2 class="text-xl font-semibold text-gray-800"><?php echo e($reservation->item->title); ?></h2>
                                </a>
                                <div class="flex gap-5 flex-col md:flex-row">
                                    <img src="<?php echo e(asset('storage/media/'.$reservation->item->thumbnail->name)); ?>" alt=""
                                         class="w-full md:w-1/4">
                                    <div>
                                        <p class="text-gray-800">Start Date : <?php echo e($reservation->start_date->format('d/M/Y')); ?></p>
                                        <p class="text-gray-800">End Date : <?php echo e($reservation->end_date->format('d/M/Y')); ?></p>
                                        <p class="text-gray-800">Price : <?php echo e(number_format($reservation->payment_amount,'2', '.',' ')); ?> <?php echo e($reservation->payment_currency); ?></p>
                                        <p class="text-gray-800">Status : <?php echo e(strtoupper($reservation->status)); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="mt-4">
                        <?php echo e($reservations->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cars\resources\views/profile/reservations.blade.php ENDPATH**/ ?>