<?php $__env->startSection('title', $page->name); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('front.breadcrumbs',['breadcrumbs' => [
        ['name' => 'Home', 'url' => route('front.home')],
        ['name' => $page->name, 'url' => route('front.page.show', $page->slug)]
    ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container page flex gap-5">
        <div class="w-1/4 bg-white p-3 rounded h-max hidden md:block">
            <?php if (isset($component)) { $__componentOriginalb3178872fdf630b269268f563f3c79c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3178872fdf630b269268f563f3c79c4 = $attributes; } ?>
<?php $component = App\View\Components\PageSidebar::resolve(['page' => $page] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('page-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\PageSidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3178872fdf630b269268f563f3c79c4)): ?>
<?php $attributes = $__attributesOriginalb3178872fdf630b269268f563f3c79c4; ?>
<?php unset($__attributesOriginalb3178872fdf630b269268f563f3c79c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3178872fdf630b269268f563f3c79c4)): ?>
<?php $component = $__componentOriginalb3178872fdf630b269268f563f3c79c4; ?>
<?php unset($__componentOriginalb3178872fdf630b269268f563f3c79c4); ?>
<?php endif; ?>
        </div>
        <div class="w-full md:w-3/4 bg-white p-3">
            <h1 class="text-2xl"><?php echo e($page->name); ?></h1>
            <div class="mb-3">
                <?php echo $page->content; ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cars\resources\views/front/page/show.blade.php ENDPATH**/ ?>