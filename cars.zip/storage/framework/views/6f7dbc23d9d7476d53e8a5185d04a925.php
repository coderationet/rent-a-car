<tr class="attribbute-value-row" data-attribute-id="<?php echo e($item_attribute['id']); ?>">
    <td>
        <?php echo e($item_attribute['name']); ?>

    </td>
    <td>
        <select
            name="attribute_values[]"
            class="form-control multiple-attribute-values"

            <?php if($item_attribute['type'] == "multiselect"): ?>
                multiple=""
            <?php endif; ?>
            data-attribute-id="<?php echo e($item_attribute['id']); ?>">
            <?php $__currentLoopData = $item_attribute['values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_attribute_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option
                    value="<?php echo e($item_attribute_value['id']); ?>"
                    selected><?php echo e($item_attribute_value['name']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </td>
    <td>
        <?php if(\App\Helpers\PermissionHelper::checkIfUserHasPermission(\App\Enums\PermissionEnum::ITEM_ATTRIBUTES_CREATE)): ?>
            <!-- new value popup -->
            <button type="button"
                    class="btn btn-primary btn-xs add-new-attribute-value"
                    data-toggle="modal" data-target="#add-new-attribute-value-modal"
                    id="add-new-attribute-button"
                    data-attribute-id="<?php echo e($item_attribute['id']); ?>">
                <i class="fas fa-plus"></i> <?php echo e(__('admin/attributes.add_new_value')); ?>

            </button>
        <?php endif; ?>
        
        <button type="button"
                class="btn btn-danger btn-xs delete-attribute"
                data-attribute-id="<?php echo e($item_attribute['id']); ?>">
            <i class="fas fa-trash"></i> <?php echo e(__('admin/general.delete')); ?>

        </button>
        
    </td>
</tr>

<?php if (! $__env->hasRenderedOnce('7a0b02d3-c15d-42db-b6e7-7591c69b4c83')): $__env->markAsRenderedOnce('7a0b02d3-c15d-42db-b6e7-7591c69b4c83');
$__env->startPush('extra-footer'); ?>
    <script>
        $(function () {
            $(document).on('click', '.delete-attribute', function () {
                // delete attribute row
                $(this).parent().parent().remove();
            })
        })
    </script>
<?php $__env->stopPush(); endif; ?>
<?php /**PATH C:\laragon\www\cars\resources\views/admin/items/_attribute_value_row.blade.php ENDPATH**/ ?>