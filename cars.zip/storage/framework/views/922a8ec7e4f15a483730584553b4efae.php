<div <?php echo e($attributes->merge(['class' => 'container mx-auto '])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\laragon\www\cars\resources\views/components/container.blade.php ENDPATH**/ ?>